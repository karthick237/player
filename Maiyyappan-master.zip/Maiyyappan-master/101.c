#include<stdio.h>
void main()
{
char a[10];
int n,i,m,1l=0;
clrscr();
scanf("%s",&a);
scanf("%d",&n);
for(i=0;a[i]!='\0';i++)
{
l++;
}
m=l1-n;
for(i=m;i<l1;i++)
{
printf("%c",a[i]);
}
}
