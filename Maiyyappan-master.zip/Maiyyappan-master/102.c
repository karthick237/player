#include<stdio.h>
void main()
{
    int n1;
    scanf("%d",&n1);
    if(n1%2==0)
    {
        n=n1/2;
        printf("%d",n);
    }
    else
    {
        printf("%d",n1);
    }
}
