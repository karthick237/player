#include<stdio.h>
#include<math.h>
void main()
{
long int N,k,p=0;
clrscr();
scanf("%ld%ld",&N,&k);
p=pow(N,k);
printf("%ld",p);
}
