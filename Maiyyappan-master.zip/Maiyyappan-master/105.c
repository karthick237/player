#include<stdio.h>
void main()
{
int a,a1;
clrscr();
scanf("%d%d",&a,&a1);
printf("%d%d",a,a1);
}
