#include<stdio.h>
void main()
{
int a,b,c,ans;
clrscr();
scanf("%d%d%d",&a,&b,&c);
ans=a*b/c;
printf("%d",ans);
}
