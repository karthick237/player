#include<stdio.h>
#include<conio.h>
void main()
{
int a,n,d,tot;
printf("enter the a,n,d");
scanf("%d%d%d",&a,&n,&d);
tot=a+(n-1)*d;
printf("%d",tot);
getch();
}
