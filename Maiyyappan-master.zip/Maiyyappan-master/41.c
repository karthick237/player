#include<stdio.h>
void main()
{
char str[5];
  int k,i;
scanf("%s",&str);
printf("enter a limit");
scanf("%d",&k);
for(i=0;i<=k;i++)
{
printf("%s",str);
}
}
