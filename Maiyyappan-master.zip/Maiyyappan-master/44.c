#include<stdio.h>
void main()
{
int n;
scanf("%d",&n);
if((n>1)&&(n<10))
{
printf("%d",n);
}
else
{
    printf("not in range");
}
}
