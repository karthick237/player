#include<stdio.h>
void main()
{
int a,b,sum=0;
scanf("%d%d",&a,&b);
sum=a+b;
printf("%d",sum);
}
