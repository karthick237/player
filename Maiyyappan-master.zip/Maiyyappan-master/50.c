#include<stdio.h>
void main()
{
int n;
scanf("%d",&n);
if(n%2==0)
{
printf("yes");
}
else
{
printf("no");
}
}
