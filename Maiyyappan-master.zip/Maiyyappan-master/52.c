#include<stdio.h>
void main()
{
int N;
clrscr();
scanf("%d",&N);
if(N==1)
printf("one");
else if(N==2)
printf("two");
else if(N==3)
printf("three");
else if(N==4)
printf("four");
else if(N==5)
printf("five");
else if(N==6)
printf("six");
else if(N==7)
printf("seven");
else if(N==8)
printf("eight");
else if(N==9)
printf("nine");
else if(N==10)
printf("ten");
else
printf("invalid");
getch();
}
