include<stdio.h>
void main()
{
int i,n,sum=0,rem;
clrscr();
scanf("%d",&n);
while(n)
{
rem=n%10;
sum=sum+r;
n=n/10;
}
printf("%d",sum);
getch();
}
