#include<stdio.h>
void main()
{
int N;
clrscr();
scanf("%d",&N);
if(N%2==0)
printf("%d",N);
else
printf("%d",N-1);
getch();
}
