
#include <stdio.h>
#include<conio.h>

int main()
{
    int a,mul,i;
    scanf("%d",&a);
    for(i=1;i<=5;i++)
    { 
        mul=a*i;
        printf("%d ",mul);
    }
    return 0;
}
