#include<stdio.h>
void main()
{
int i,n1,sum=0;
clrscr();
scanf("%d",&n1);
for(i=1;i<=n1;i++)
{
sum=sum+i;
}
printf("%d",sum);
getch();
}
