#include<stdio.h>
void main()
{
char a[100];
int i,N;
clrscr();
scanf("%s",&a);
scanf("%d",&N);
for(i=0;i<N;i++)
{
printf("%c",a[i]);
}
}
