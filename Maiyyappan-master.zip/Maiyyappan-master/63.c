#include<stdio.h>
void main()
{
int a[10],i,c=0;
clrscr();
for(i=0;i<10;i++)
{
scanf("%d",&a[i]);
}
c=a[0];
for(i=1;i<10;i++)
{
if(a[i]<k)
c=a[i];
}
printf("%d",c);
}
