#include<stdio.h>
#include<conio.h>
void main()
{
int a,b,N;
clrscr();
scanf("%d%d",&a,&b);
N=a+b;
if(N%2!=0)
printf("odd");
else
printf("even");
}
