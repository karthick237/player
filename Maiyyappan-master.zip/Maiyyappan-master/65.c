#include<stdio.h>
void main()
{
char str[100];
clrscr();
scanf("%[^\n]",&str);
if(printf("%s",str))
{
}
}
