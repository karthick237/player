#include<stdio.h>
void main()
{
int N,k;
scanf("%d",&N);
k=((N/10)+1)*10;
printf("%d",k);
}
