#include<stdio.h>
void main()
{
float a;
int N;
scanf("%f",&a);
  N=a+1;
printf("%d",N);
}
