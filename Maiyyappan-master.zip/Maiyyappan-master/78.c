#include<stdio.h>
void main()
{
int N;
clrscr();
scanf("%d",&N);
if(N%13==0)
printf("yes");
else
printf("no");
getch();
}
