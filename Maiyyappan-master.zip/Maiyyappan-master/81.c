#include<stdio.h>
void main()
{
int n,m,d=0;
clrscr();
scanf("%d%d",&n,&m);
if(m>n)
d=m-n;
else
d=n-m;
printf("%d",m);
}
