#include<stdio.h>
void main()
{
 float a,b,k;
 scanf("%f%f",&a,&b);
 k=a*b;
 printf("%.5f",k);
}
