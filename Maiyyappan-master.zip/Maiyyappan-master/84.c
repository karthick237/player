#include<stdio.h>
void main()
{
char a1;
clrscr();
scanf("%c",&a1);
printf("%d",a1);
getch();
}
