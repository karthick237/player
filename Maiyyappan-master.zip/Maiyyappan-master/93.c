#include<stdio.h>
void main()
{
int i,N,k=0;
clrscr();
scanf("%d",&N);
k=N+273;
printf("%d",k);
}
