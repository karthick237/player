#include<stdio.h>
void main()
{
int p,N,r,k=0;
clrscr();
scanf("%d%d%d",&p,&N,&r);
k=(p*N*r)/100;
printf("%d",k);
}
