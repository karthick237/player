#include <stdio.h>
#include<conio.h>
int main()
{
 int a,i,k,sum=0;
 scanf("%d",&a);
 scanf("%d",&k);
 for(i=0;i<k;i++)
 {
     sum=a*a;
 }
 printf("%d",sum);
    return 0;
}
