    
#include <stdio.h>

int main()
{
   int n,f=0,i;
   scanf("%d",&n);
   for(i=0;i<=i;i++)
   {
       if(i*i==n)
       {
           f=1;break;
       }
   }
   if(f==1)
   printf("yes");
   else
   printf("no");

}
