#include<stdio.h>
int main() 
{
   int a,m=0,c=0;
   scanf("%d",&a);
   m=a/2;
   c=m+1;
   printf("%d",c)
}
