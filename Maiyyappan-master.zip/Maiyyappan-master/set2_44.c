#include<stdio.h>
void main()
{
	char a[100];
	int l=0,i,j,n;
  clrscr();
	scanf("%s",a);
	scanf("%d",&n);
	for(i=0;a[i]!='\0';i++)
{
l++;
}
	
  for(i=c;i<l;i++)
  {
	printf("%c",a[i]);
  }
	for(i=0;i<c;i++)
  {
	printf("%c",a[i]);
  }
  }
