#include<stdio.h>
#include<math.h>
void main()
{
    int a;
	float res;
	scanf("%d",&a);
	
  ans=sin(n*3.14/180);
print("%.1f",ans);
	}
