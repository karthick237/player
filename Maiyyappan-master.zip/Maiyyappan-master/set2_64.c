#include<stdio.h>
#include<conio.h>
void main()
{
int a,b,s;
clrscr();
scanf("%d%d",&a,& b);
s=a+b;
if(s%2==0)
printf("even ");
else 
printf("no ");

}
