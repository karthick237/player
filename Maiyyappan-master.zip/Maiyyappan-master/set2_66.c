#include<stdio.h>
#include<conio.h>
void main()
{
int n,i,f=0;
clrscr();
for(i=2;i<=/2;i++)
{
if(n%i==0)
{
f=1;
break;
}
}
if(f==0)
printf("prime no");
else 
printf("no");
}
