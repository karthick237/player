#include<stdio.h>
#include<conio.h>
void main()
{
int a;
clrscr();
scanf("%d",&a);
if(a%7==0)
printf("yes");
else 
printf("no");
}
