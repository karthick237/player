#include<stdio.h>
#include<conio.h>
void main()
{
int a,b,d;
clrscr();
scanf("%d%d",&a,&b);
d=a-b;
if(d%2==0)
printf("even");
else 
printf("odd");
}
