#include <stdio.h>
int main() 
{
	int n,res;
	scanf("%d",&n);
	res=~n;
	printf("%d",res);
  return 0;
  }
